const express = require('express');
const joyasRoutes = require('./routes/joyasRoutes');
const app = express();
const PORT = process.env.PORT || 3000;

app.use('/joyas', joyasRoutes);

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
