const generarInforme = (req, res, next) => {
    // Implementa la lógica para generar informes
    console.log(`Se realizó una consulta a la ruta ${req.path}`);
    next();
  };
  
  module.exports = generarInforme;
  